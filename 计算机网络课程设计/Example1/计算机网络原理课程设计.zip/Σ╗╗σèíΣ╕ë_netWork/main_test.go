package main

import (
	"fmt"
	"golang.org/x/net/ipv4"
	"net"
	"netWork/config"
	"syscall"
	"testing"
)

func IPv4CheckSum(data []byte) uint16 {
	var (
		sum    uint32
		length int = len(data)
		index  int
	)
	//以每16位为单位进行求和，直到所有的字节全部求完或者只剩下一个8位字节（如果剩余一个8位字节说明字节数为奇数个）
	for length > 1 {
		sum += uint32(data[index])<<8 + uint32(data[index+1])
		index += 2
		length -= 2
	}
	//如果字节数为奇数个，要加上最后剩下的那个8位字节
	if length > 0 {
		sum += uint32(data[index])
	}
	//加上高16位进位的部分
	sum += sum >> 16
	//返回时求反
	return uint16(^sum)
}

func TestMain(m *testing.M) {

	// 设置源IP地址和目的IP地址，用ipv4下的回环IP做示例
	source, _ := net.ResolveIPAddr("ip4", config.Config.GetString("client.IP"))
	destination, _ := net.ResolveIPAddr("ip4", config.Config.GetString("server.IP"))

	// 创建raw socket，只有raw socket才能捕获到网络层数据包
	// 第一个参数为地址域
	// 常用的有： AF_INET  表示使用ipv4地址
	//			AF_INET6 表示使用ipv6地址
	//			AF_UNIX  表示使用绝对路径名作为地址，即在同一台机器上进行进程通信
	// 第二个参数为socket类型
	// 常用的有： Stream Socket    表示有序的、可靠的、双向的和基于连接的字节流，是TCP socket
	//			Datagram Sockets 表示无连接的、不可靠的和使用固定大小（通常很小）缓冲区的数据服务，是UDP socket
	//			Raw Sockets		 为用户提供了访问底层通信协议的能力，是可以捕获网络层数据包的socket
	// 第三个参数为制定协议
	// 常用的有： IPPROTO_TCP  接收TCP协议的数据
	// 			IPPROTO_UDP  接收UDP协议
	// 			IPPROTO_ICMP 接收ICMP协议
	//			IPPROTO_RAW  只能用来发送IP数据包，不能接收数据
	socket, err := syscall.Socket(syscall.AF_INET, syscall.SOCK_RAW, syscall.IPPROTO_RAW)
	if err != nil {
		fmt.Print("create raw socket error\n" + err.Error())
		return
	}
	defer syscall.Close(socket)

	// 开启IP_HDRINCL，开启后就不会自动产生一个IP数据包首部，需要我们自行生成一个，方便我们设置自定义协议
	err = syscall.SetsockoptInt(socket, syscall.IPPROTO_IP, syscall.IP_HDRINCL, 1)
	if err != nil {
		fmt.Println("开启IP_HDRINCL错误" + err.Error())
		return
	}

	// 应用层数据
	application := []byte("233")

	// 自定义传输层协议头
	transmission := []byte{
		uint8(12345 >> 8), uint8(12345 % 256), // 源端口
		uint8(54321 >> 8), uint8(54321 % 256), // 目的端口
	}

	// IP头，重要的是协议字段写233号协议
	ipHeader := ipv4.Header{
		Version:  4,
		Len:      20,
		TotalLen: len(application) + len(transmission) + 20,
		TTL:      64,
		Protocol: 233,
		Dst:      destination.IP.To4(),
		Src:      source.IP.To4(),
	}
	// 生成字节串
	ip, _ := ipHeader.Marshal()
	// 计算校验和
	ipHeader.Checksum = int(IPv4CheckSum(ip))
	ip, _ = ipHeader.Marshal()

	// 组装报文
	payload := append(ip, transmission...)
	payload = append(payload, application...)

	// 通过raw socket发送报文
	destinationAddress := syscall.SockaddrInet4{
		Port: 0,
		Addr: [4]byte{
			destination.IP.To4()[0],
			destination.IP.To4()[1],
			destination.IP.To4()[2],
			destination.IP.To4()[3],
		},
	}
	err = syscall.Sendto(socket, payload, 0, &destinationAddress)
	if err != nil {
		fmt.Println("发送错误" + err.Error())
		return
	}
	fmt.Println("发送成功")
}
