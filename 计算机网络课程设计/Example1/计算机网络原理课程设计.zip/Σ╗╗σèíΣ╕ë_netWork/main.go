package main

import (
	"fmt"
	"golang.org/x/net/ipv4"
	"net"
	"netWork/config"
)

func main() {
	// 开启监听，第一个参数指定协议为运输层下的233号协议，ip从配置文件中读取
	listener, err := net.ListenPacket("ip4:233", config.Config.GetString("server.IP"))
	if err != nil {
		fmt.Println("开启监听错误" + err.Error())
		return
	}
	defer listener.Close()

	// 从监听者创建底层链接
	connection, err := ipv4.NewRawConn(listener)
	if err != nil {
		fmt.Println("创建Connection错误" + err.Error())
		return
	}
	defer connection.Close()

	// 开启无限循环获取报文
	for {
		buf := make([]byte, 2000)
		// 获取报文同时解析IP报文，得到IP头和数据部分（整个运输层数据包）
		ipHeader, payload, _, err := connection.ReadFrom(buf)
		if err != nil {
			fmt.Println("解析IP头错误" + err.Error())
			return
		}
		// 打印IP头
		fmt.Println(ipHeader)
		// 打印数据部分
		fmt.Println(payload)
	}
}
