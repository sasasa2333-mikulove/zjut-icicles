package com.example.helloandroid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Vector;

public class MainActivity extends Activity implements CompoundButton.OnCheckedChangeListener, RadioGroup.OnCheckedChangeListener {
    private TextView labelView;
    private TextView historyView;
    private PointView touchView;
    private Switch isBackSwitch;
    private RadioGroup rateRadioGroup;
    private Button showButton;
    private RadioGroup colorRadioGroup;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 触摸区域
        touchView =  findViewById(R.id.touch_area);
        // 事件参数区
        labelView = findViewById(R.id.event_label);
        // 历史数据
        historyView = findViewById(R.id.history_label);
        //是否倒放
        isBackSwitch =findViewById(R.id.isBack);
        //倍速组
        rateRadioGroup=findViewById(R.id.rate);
        showButton=findViewById(R.id.show);
        colorRadioGroup=findViewById(R.id.color);

        isBackSwitch.setOnCheckedChangeListener(this);
        rateRadioGroup.setOnCheckedChangeListener(this);
        colorRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId==R.id.aa)
                    touchView.resetColor(Color.RED);
                else if (checkedId==R.id.bb)
                    touchView.resetColor(Color.BLACK);
                else if (checkedId==R.id.cc)
                    touchView.resetColor(Color.BLUE);
                else if (checkedId==R.id.dd)
                    touchView.resetColor(Color.MAGENTA);
            }
        });
        showButton.setOnClickListener(i->{
            touchView.askShow();
        });

        touchView.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint({"SetTextI18n", "ClickableViewAccessibility"})
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        touchView.onTouchEvent(event);
                        Display("ACTION_DOWN", event);
                        break;
                    case MotionEvent.ACTION_UP:
                        touchView.onTouchEvent(event);
                        Display("ACTION_UP", event);
                        break;
                    case MotionEvent.ACTION_MOVE:
                        touchView.onTouchEvent(event);
                        Display("ACTION_MOVE", event);
                        break;
                }
                return true;
            }

            // 解析事件为屏幕显示文字
            private void Display(String eventType, MotionEvent event) {
                int x = (int) event.getX();
                int y = (int) event.getY();
                float pressure = event.getPressure();
                float size = event.getSize();
                int RawX = (int) event.getRawX();
                int RawY = (int) event.getRawY();

                String msg = "";
                msg += "事件类型：" + eventType + "\n";
                msg += "相对坐标：" + String.valueOf(x) + "," + String.valueOf(y) + "\n";
                msg += "绝对坐标：" + String.valueOf(RawX) + "," + String.valueOf(RawY) + "\n";
                msg += "触点压力：" + String.valueOf(pressure) + "，  ";
                msg += "触点尺寸：" + String.valueOf(size) + "\n";
                labelView.setText(msg);
            }
        });
    }

    private void ProcessHistory(Vector<Point> history) {
//        // 绘制历史移动轨迹
//        for (int i = 0; i < history.size(); i++) {
//            Point p = history.get(i);
//            System.out.println(p.x);
//            touchView.get(p.x,p.y);
//        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        touchView.updateIsBack(isChecked);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if(checkedId==R.id.a)
            touchView.setRate(1.0);
        else if (checkedId==R.id.b)
            touchView.setRate(1.5);
        else if (checkedId==R.id.c)
            touchView.setRate(3.0);
        else if (checkedId==R.id.d)
            touchView.setRate(0.5);
        else if (checkedId==R.id.e)
            touchView.setRate(0.1);
    }
}
