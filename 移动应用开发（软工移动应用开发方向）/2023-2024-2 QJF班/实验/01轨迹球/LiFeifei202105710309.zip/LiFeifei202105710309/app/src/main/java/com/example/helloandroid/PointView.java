package com.example.helloandroid;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.Collections;

/**
 * @Author: Cassifa
 * @CreateTime: 2024-04-07  06:05
 * @Description:
 */
public class PointView extends View {
    private final Paint paint = new Paint();
    //边长
    private final float radius = 60;
    private Circle circle;

    private Boolean isBack=false;

    //倍速
    private double rate=1.0;

    public void updateIsBack(Boolean isBack){
        this.isBack=isBack;
    }
    public void setRate(double newRate){
        rate=newRate;
    }

    public PointView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public void resetColor(int color){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            paint.setColor(color);
            invalidate();
        }
    }

    private void init() {
        paint.setColor(0xffff0000);
        paint.setStyle(Paint.Style.FILL);
        //平滑
        paint.setAntiAlias(true);
    }

    private void initMetaballs() {
        circle = new Circle();
        circle.center = new float[]{(radius), radius};
        circle.radius = radius;
        circle.roadX.add(radius);
        circle.roadY.add(radius);
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        int color=paint.getColor();
        //初始化
        if (circle==null) {
            initMetaballs();
        }

        final Circle circle1 = circle;
        @SuppressLint("DrawAllocation") RectF ball1 = new RectF();
        ball1.left = circle1.center[0] - circle1.radius;
        ball1.top = circle1.center[1] - circle1.radius;
        ball1.right = ball1.left + circle1.radius * 2;
        ball1.bottom = ball1.top + circle1.radius * 2;
        canvas.drawCircle(ball1.centerX(), ball1.centerY(), circle1.radius, paint);

        paint.setColor(Color.BLACK);
        paint.setTextSize(40);
        String text = "李飞飞202105710309";
        float textWidth = paint.measureText(text); // 获取文本的宽度
        canvas.drawText(text, ball1.centerX()-textWidth/2
                , ball1.centerY(), paint);
        paint.setColor(color);
    }

    private Circle touchCircle;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float slideX, slideY;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (isOnPoint(circle,event.getX(),event.getY())) {
                    touchCircle = circle;
                    touchCircle.roadX.remove(0);
                    touchCircle.roadY.remove(0);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if(touchCircle != null && !touchCircle.isSlide) {
                    slideX = event.getX();
                    slideY = event.getY();
                    touchCircle.roadX.add(slideX);
                    touchCircle.roadY.add(slideY);
                    touchCircle.center[0] = slideX;
                    touchCircle.center[1] = slideY;
                    invalidate();
                }
                break;
            case MotionEvent.ACTION_UP:
                if(touchCircle != null&& !touchCircle.isSlide) {
//                    show();
                }
                break;
        }
        return true;
    }
    public void askShow(){
        if(touchCircle != null&& !touchCircle.isSlide) {
            show();
        }
    }

    private void show() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                circle.isSlide = true;
                if(isBack){
                    Collections.reverse(circle.roadX);
                    Collections.reverse(circle.roadY);
                }
                for (int i =0;i<circle.roadX.size();i++) {
                    circle.center[0] = circle.roadX.get(i);
                    circle.center[1] = circle.roadY.get(i);
                    try {
                        Thread.sleep((long) (10/rate));
                        handler.sendEmptyMessage(0);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                float startX,startY;
                if(isBack){
                    startX=circle.roadX.get(circle.roadX.size()-1);
                    startY=circle.roadY.get(circle.roadX.size()-1);
                }
                else {
                    startX = circle.roadX.get(0);
                    startY = circle.roadY.get(0);
                }
                circle.roadX.clear();
                circle.roadY.clear();
                circle.roadX.add(startX);
                circle.roadY.add(startY);
                circle.isSlide = false;
            }
        }).start();
    }

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                invalidate();
            }
        }
    };

    //是否触碰了点
    private boolean isOnPoint(Circle circle,float x, float y){
        return (x > circle.center[0] - radius && x < circle.center[0] + radius
                && y > circle.center[1] - radius && y < circle.center[1] + radius);
    }
}
