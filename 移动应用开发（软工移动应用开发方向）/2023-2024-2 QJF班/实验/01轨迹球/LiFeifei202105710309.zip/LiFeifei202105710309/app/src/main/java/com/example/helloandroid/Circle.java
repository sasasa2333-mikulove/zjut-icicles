package com.example.helloandroid;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: Cassifa
 * @CreateTime: 2024-04-08  07:10
 * @Description:
 */
public class Circle {
    public float[] center;
    public float radius;
    public List<Float> roadX = new ArrayList<Float>();
    public List<Float> roadY = new ArrayList<Float>();
    public boolean isSlide = false;
}
