package com.example.helloandroid;

/**
 * @Author: Cassifa
 * @CreateTime: 2024-04-07  05:46
 * @Description:
 */
public class Point {
    public float x, y;

    Point(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
