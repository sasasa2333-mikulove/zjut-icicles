package com.example.helloandroid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * @Author: Cassifa
 * @CreateTime: 2024-04-07  05:25
 * @Description:
 */
public class Test extends View {
    float x=50,y=50;
    public Test(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
    void get(float a,float b){
        x=a;y=b;
        invalidate();
    }
    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        canvas.drawColor(Color.BLUE);
        Paint paint =new Paint();
        paint.setColor(Color.BLACK);
        canvas.drawCircle(x,y,30,paint);

    }
}
